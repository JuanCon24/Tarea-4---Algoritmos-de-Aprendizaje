# analisisdedato

En este repositoio esta documentada con todos los algortimos que se tuilizaron en la actividad de analisis de datos.

Se utilizo el lenguaja de progmacion Pyhton orientado para el anàlisis de dato Y Machine Learning para la agrupacion de informacion y la mineria de dato..

Plaforma utilizada para la realizaciòn de esta actividad Jupyter notebooks Anaconda.


Saludos!
